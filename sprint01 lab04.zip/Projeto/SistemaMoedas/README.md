# Sistema de Matrículas 

Uma universidade que pretende informatizar seu sistema de matrículas.

# Histórias de Usuário

Como aluno, gostaria de cadastrar no sistema.

Como aluno, gostaria de selecionar a instituição.

Como aluno, gostaria de resgatar moedas.

Como usuario, gostaria de logar dentro do sistema.

Como empresa, gostaria de cadastrar no sistema.

Como empresa, gostaria de informar vantagens.

Como empresa, gostaria de adicionar foto.

Como empresa, gostaria de adicionar descrição.

Como professor, gostaria de receber moedas.

Como professor, gostaria de consultar saldo.

Como professor, gostaria de consultar transações.

Como professor, gostaria de distrubuir moedas.

Como professor, gostaria de informar o aluno.

Como professor, gostaria de informar os motivos de escolha.


## Professor responsável

* Cleiton Silva Tavares

## Alunos integrantes da equipe

Hugo Poletto Alacoque Gomes

Leonardo Gorle Almeida

Vitor Costa Salem

Yollanda Lima Barbosa
