# Histórias de Usuário

Como secretária da universidade, gostaria de gerar o currículo para cada semestre, para ter o controle das informações sobre as disciplinas, dos professores e dos alunos

Como um aluno, eu posso matricular em disciplinas obrigatórias, para ter acesso as informações posteriormente.

Como um aluno, eu posso matricular em disciplinas optativas, para ter acesso as informações posteriormente

Como um professor, posso ter acesso as informações dos alunos, para saber quais disciplinas que os alunos estão matriculados.

Como um usuário, devo ter senha, para que possa fazer o login do sistema. 

# Alunos

Hugo Poletto Gomes

Leonardo Gorle Almeida

Vitor Costa Salem

Yollanda Lima Barbosa
