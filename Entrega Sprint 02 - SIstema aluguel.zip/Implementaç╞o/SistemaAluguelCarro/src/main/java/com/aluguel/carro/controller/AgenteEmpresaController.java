package com.aluguel.carro.controller;

import com.aluguel.carro.entity.AgenteEmpresa;
import com.aluguel.carro.repository.AgenteEmpresaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/agenteEmpresa")
public class AgenteEmpresaController {
    @Autowired
    private AgenteEmpresaRepository agenteEmpresaRepository;


    @RequestMapping(value = "/cadastrar", method = RequestMethod.GET)
    public String cadastroAgenteEmpresa() {
        return "agentesEmpresa/cadastroAgenteEmpresa";
    }

    @RequestMapping(value = "/cadastrar", method = RequestMethod.POST)
    public String cadastrarAgenteEmpresaNoSistema(AgenteEmpresa agenteEmpresa) {
        agenteEmpresaRepository.save(agenteEmpresa);
        return "redirect:/{agenteEmpresa.getId()}";
    }

}
