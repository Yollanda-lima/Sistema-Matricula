package com.aluguel.carro.controller;

import com.aluguel.carro.entity.Automovel;
import com.aluguel.carro.repository.AutomovelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/automovel")
public class AutomovelController {
    @Autowired
    private AutomovelRepository automovelRepository;


    @RequestMapping(value = "/cadastrar", method = RequestMethod.GET)
    public String cadastroAutomovel() {
        return "automoveis/cadastroAutomovel";
    }

    @RequestMapping(value = "/cadastrar", method = RequestMethod.POST)
    public String cadastrarAutomovelNoSistema(Automovel automovel) {
        automovelRepository.save(automovel);
        return "redirect:/{automovel.getId()}";
    }

}
