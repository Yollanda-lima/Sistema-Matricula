package com.aluguel.carro.entity;

import javax.persistence.*;

@MappedSuperclass
public abstract class Usuario {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;

    @Column(name="nomeUsuario", nullable=false)
    private String nomeUsuario;
    @Column(name="senha", nullable=false)
    private String senha;
    @Column(name="nomeCompleto", nullable=false)
    private String nomeCompleto;
    @Column(name="cpf", nullable=false)
    private int cpf;
    @Column(name="endereco", nullable=false)
    private String endereco;

    public Usuario(Long id, String nomeUsuario, String senha, String nomeCompleto, int cpf, String endereco) {
        this.id = id;
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;
        this.nomeCompleto = nomeCompleto;
        this.cpf = cpf;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nomeUsuario='" + nomeUsuario + '\'' +
                ", senha='" + senha + '\'' +
                ", nomeCompleto='" + nomeCompleto + '\'' +
                ", cpf=" + cpf +
                ", endereco='" + endereco + '\'' +
                '}';
    }
}
