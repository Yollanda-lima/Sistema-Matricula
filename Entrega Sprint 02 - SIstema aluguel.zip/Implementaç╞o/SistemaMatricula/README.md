# Sistema de Aluguel de Carros

Empresa de aluguel de carros pretende automatizar sistema de aluguel de veiculos.

# Histórias de Usuário
Como cliente, gostaria de introduzir pedido de aluguel de um veiculo.

Como cliente, gostaria de modificar pedido de aluguel de um veiculo.

Como cliente, gostaria de consultar pedido de aluguel de um veiculo.

Como cliente, gostaria de cancelar pedido de aluguel de um veiculo.

Como usuario, gostaria de logar dentro do sistema.

Como usuario, gostaria de fazer cadastro no sistema.

Como agente financeiro, gostaria de avaliar o pedido de aluguel do cliente.

Como agente financeiro, gostaria de modificar o pedido de aluguel do cliente.

Como agente financeiro, gostaria de autorizar contrato de credito para o cliente.

Como agente financeiro, gostaria de emitir contrato de aluguel para o cliente.

Como agente de aluguel, gostaria de finalizar o pedido de aluguel para o cliente.




## Professor responsável

* Cleiton Silva Tavares

## Alunos integrantes da equipe

Hugo Poletto Alacoque Gomes

Leonardo Gorle Almeida

Vitor Costa Salem

Yollanda Lima Barbosa
