package org.example.enums;

public enum TipoDisciplina {
    OBRIGATORIA, OPTATIVA
}
